/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package loja;

/**
 *
 * @author 03824366010
 */
public class Invoice {
    private int itemFaturado;
    private String descricaoItem;
    private int quantidade;
    private double precoUnitario;
    
        public Invoice(int itemFaturado, String descricaoItem,int quantidade, double precoUnitario){
                this.itemFaturado = itemFaturado;
                this.descricaoItem  = descricaoItem;
                if(quantidade > 0){
                    this.quantidade = quantidade;
                }else{
                    this.quantidade = 0;
                    this.precoUnitario = precoUnitario;
                }
        }

    public int getItemFaturado() {
        return itemFaturado;
    }

    public void setItemFaturado(int itemFaturado) {
        this.itemFaturado = itemFaturado;
    }

    public String getDescricaoItem() {
        return descricaoItem;
    }

    public void setDescricaoItem(String descricaoItem) {
        this.descricaoItem = descricaoItem;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public double getPrecoUnitario() {
        return precoUnitario;
    }

    public void setPrecoUnitario(double precoUnitario) {
        this.precoUnitario = precoUnitario;
    }
        
       public double getInvoiceAmount(){
           return quantidade * precoUnitario;
       }
      
    
    public static void main(String[] args) {
        Invoice invoicePrincipal = new Invoice(1, "Teclado", 2, 25.0);
        System.out.println("Número do Item: " + invoicePrincipal.getItemFaturado());
        System.out.println("Descrição do Item: " + invoicePrincipal.getDescricaoItem());
        System.out.println("Quantidade: " + invoicePrincipal.getQuantidade());
        System.out.println("Preço Unitário: " + invoicePrincipal.getPrecoUnitario());
        System.out.println("Valor da Fatura: " + invoicePrincipal.getInvoiceAmount());
    }
    
}
