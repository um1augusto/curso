import java.util.Scanner;

public class JogoDaVelha {

    private enum Marcador {
        VAZIO,
        JOGADOR1,
        JOGADOR2
    }

    private Marcador[][] grade;
    private Marcador jogadorAtual;

    public JogoDaVelha() {
        grade = new Marcador[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                grade[i][j] = Marcador.VAZIO;
            }
        }
        jogadorAtual = Marcador.JOGADOR1;
    }
    
    private char converterMarcador(Marcador marcador){
        switch(marcador){
            case VAZIO:
                return ' ';
            case JOGADOR1:
                return 'X';
            case JOGADOR2:
                return 'O';
            default:
                return ' ';
        }
    } 
    
    public void exibirGrade(){
        for (int i = 0; i < 3; i++){
            for (int j = 0; j < 3; j++){
                System.out.print(converterMarcador(grade[i][j]));
                if(j < 2){
                    System.out.print(" | ");
                }
            }
            System.out.println();
            if(i < 2){
                System.out.println("------------");
            }
        }
    }
    
    public boolean jogar(int linha, int coluna) {
        if (linha < 0 || linha >= 3 || coluna < 0 || coluna >= 3) {
            System.out.println("Posição inválida. Tente novamente.");
            return false;
        }
        if (grade[linha][coluna] != Marcador.VAZIO) {
            System.out.println("Esta casa já está ocupada. Tente novamente.");
            return false;
        }

        grade[linha][coluna] = jogadorAtual;

        if (verificarVitoria()) {
            System.out.println("O jogador " + jogadorAtual + " venceu!");
            return true;
        } else if (verificarEmpate()) {
            System.out.println("O jogo terminou em empate!");
            return true;
        }

        jogadorAtual = (jogadorAtual == Marcador.JOGADOR1) ? Marcador.JOGADOR2 : Marcador.JOGADOR1;
        return false;
    }
    
    private boolean verificarVitoria(){
        // Verificar linhas e colunas
        for (int i = 0; i < 3; i++) {
            if (grade[i][0] == grade[i][1] && grade[i][1] == grade[i][2] && grade[i][0] != Marcador.VAZIO) {
                return true;
            }
            if (grade[0][i] == grade[1][i] && grade[1][i] == grade[2][i] && grade[0][i] != Marcador.VAZIO) {
                return true;
            }
        }
        // Verificar diagonais
        if ((grade[0][0] == grade[1][1] && grade[1][1] == grade[2][2] && grade[0][0] != Marcador.VAZIO) ||
            (grade[0][2] == grade[1][1] && grade[1][1] == grade[2][0] && grade[0][2] != Marcador.VAZIO)) {
            return true;
        }
        return false;
    }
    
    private boolean verificarEmpate() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (grade[i][j] == Marcador.VAZIO) {
                    return false;
                }
            }
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        JogoDaVelha jogo = new JogoDaVelha();

        while (true) {
            System.out.println("Jogador " + jogo.jogadorAtual + ", é sua vez.");
            jogo.exibirGrade();
            System.out.print("Informe a linha (0-2): ");
            int linha = scanner.nextInt();
            System.out.print("Informe a coluna (0-2): ");
            int coluna = scanner.nextInt();

            if (jogo.jogar(linha, coluna)) {
                break;
            }
        }

        scanner.close();
    }

}